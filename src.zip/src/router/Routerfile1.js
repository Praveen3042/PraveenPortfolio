import React from 'react'
import {Routes, Route } from 'react-router-dom';
import Tablemap from '../pages/tablemap';
import { Check1 } from '../pages/Check1';
export const Routerfile1 = () => {
    return (
        <div>
            
                <Routes>
                    <Route path="/" element={<Tablemap />} />
                    <Route path="/nextpage" element={<Check1 />} />
                </Routes>

        </div>
    )
}
