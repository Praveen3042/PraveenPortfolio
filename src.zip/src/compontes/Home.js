import React from 'react'
import "../styles/home.css"
import {FaGithub, FaLinkedin} from "react-icons/fa";
import { IoMail } from "react-icons/io5";
import resume from "./s.praveen.pdf"

const Home = () => {
  return (
    

      <div className='homepage'>
        <div className='homename'>
          <h2>This is</h2>
          <h1>Praveen S</h1>
        </div>
        <div className='homedevp'>
          <span></span>
        </div>
        <br/>
        <br/>
        <div className='homeicon'>
          <a href='https://github.com/Praveen3042' target='_blank' >
          <FaGithub />
          </a>
          &nbsp;&nbsp;
          {/* <a href='' target='_blank' >
          <IoMail />
          </a> */}
          &nbsp;&nbsp;
          <a href='https://www.linkedin.com/in/praveen-s-6566b9262/' target='_blank' >
          <FaLinkedin />
          </a>
         
        </div>
        <br/>
        <div className='donbnt'>
           <a href={resume} download="praveen.pdf">GET CV</a>

        </div>
      </div>

   

  )
}

export default Home