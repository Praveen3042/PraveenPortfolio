import React from 'react'
import '../styles/skill.css'

import { FaHtml5, FaJs, FaReact } from "react-icons/fa";
import { SiCss3, SiMongodb, SiExpress } from "react-icons/si";

const Skill = () => {
    return (
       
            <div className='skillmain1'>
                <h1>skills</h1>
                <br />
                <div className='skill'>
                    <div className='skill1'>
                        <div className='skillicon'>
                            <FaHtml5 /> <ProgressBar title="HTML" percentage={90} />
                        </div>
                        <br />
                        <div className='skillicon'>
                            <SiCss3 /> <ProgressBar title="CSS" percentage={85} />
                        </div>
                        <br />
                        <div className='skillicon'>
                            <FaJs /> <ProgressBar title="JAVASCRIPT" percentage={75} />
                        </div>
                    </div>
                    <div className='skill1'>
                        <div className='skillicon'>
                            <FaReact /> <ProgressBar title="React js" percentage={80} />
                        </div>
                        <br />
                        <div className='skillicon'>
                            <SiMongodb /> <ProgressBar title="MongoDB" percentage={75} />
                        </div>
                        <br />
                        <div className='skillicon'>
                            <SiExpress /> <ProgressBar title="Express jS" percentage={70} />
                        </div>



                    </div>
                </div>
            </div>

       

    )
}
export default Skill

//the progreebar 
const ProgressBar = ({ title, percentage }) => {
    return (
        <div className="progress-container">
            <div className="progress-title">
                {title}
                <span className="progress-percentage">{percentage}%</span>
            </div>
            <div className="progress-bar">
                <div
                    className="progress-bar-inner"
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    );
};



