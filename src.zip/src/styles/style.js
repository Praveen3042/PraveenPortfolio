// import "../styles/color.css"
// export const styles = {
//     navbar: {
//       backgroundColor: 'var(--blue-800)',
//       fontFamily: 'Protest Guerrilla, sans-serif',
//       fontWeight: 400,
//       fontStyle: 'normal',
//       fontSize:20,
//     },
//     brand: {
//         color: 'var(--blue-400)', 
//         fontWeight: 500,
//         fontSize:25,
//     },
//     navdiv:{
//       backgroundColor: 'var(--blue-800)',
//     },
//     navlist:{
//       color: 'var(--blue-400)',
//       fontSize:20,
//     },
//     navlistHover:{
//       color: 'var(--blue-300)',
//       fontSize:20,

//     },
    
//   };